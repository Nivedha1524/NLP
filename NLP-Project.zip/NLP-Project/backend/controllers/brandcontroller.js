const Brand = require("../models/Brand");
const { fetchAllSources, analyze, generateTimeline, extractKeywords } = require("../services/brandService");

module.exports = (io) => ({

    async getBrand(req, res) {
        try {
            const brand = req.params.name;

            const posts = await fetchAllSources(brand);
            const sentiment = await analyze(posts);
            const timeline = generateTimeline(posts);
            const words = extractKeywords(posts);

            const data = {
                name: brand,
                totalMentions: posts.length,
                timeline: timeline,
                words: words,
                ...sentiment
            };

            // Save to DB
            try {
                await Brand.create(data);
            } catch (dbError) {
                console.log("Mocking DB save because MongoDB might be offline locally.");
            }

            // Send real-time update
            io.emit("update", data);

            res.json(data);

        } catch (err) {
            console.error(err);
            res.status(500).json({ error: "Something went wrong" });
        }
    }

});