const mongoose = require("mongoose");

const BrandSchema = new mongoose.Schema({
    name: String,
    totalMentions: Number,
    positive: Number,
    neutral: Number,
    negative: Number,
    timeline: Object,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Brand", BrandSchema);