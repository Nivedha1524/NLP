const express = require("express");
const http = require("http");
const cors = require("cors");
const mongoose = require("mongoose");
const { Server } = require("socket.io");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: "*" }
});

// MongoDB connect
mongoose.connect("mongodb://127.0.0.1:27017/brandDB")
.then(() => console.log("MongoDB Connected"));

// Socket setup
io.on("connection", (socket) => {
    console.log("User connected");

    socket.on("disconnect", () => {
        console.log("User disconnected");
    });
});

// Auth routes
app.post("/api/login", (req, res) => {
    const { email, password } = req.body;
    if (email === "admin@brandvision.ai" && password === "password") {
        return res.json({ token: "mock_secure_jwt_token_123" });
    }
    return res.status(401).json({ error: "Invalid credentials" });
});

// Routes
const brandRoutes = require("./routes/brandRoutes.js")(io);
app.use("/api", brandRoutes);

server.listen(5000, () => console.log("Server running"));